# Copyright 2023 NXP
# NXP Confidential and Proprietary. This software is owned or controlled by NXP and may only be used strictly in
# accordance with the applicable license terms. By expressly accepting such terms or by downloading, installing,
# activating and/or otherwise using the software, you are agreeing that you have read, and that you agree to
# comply with and are bound by, such license terms.  If you do not agree to be bound by the applicable license
# terms, then you may not retain, install, activate or otherwise use the software.

import SDL
import utime as time
import usys as sys
import lvgl as lv
import lodepng as png
import ustruct
import fs_driver

lv.init()
SDL.init(w=480,h=272)

# Register SDL display driver.
disp_buf1 = lv.disp_draw_buf_t()
buf1_1 = bytearray(480*10)
disp_buf1.init(buf1_1, None, len(buf1_1)//4)
disp_drv = lv.disp_drv_t()
disp_drv.init()
disp_drv.draw_buf = disp_buf1
disp_drv.flush_cb = SDL.monitor_flush
disp_drv.hor_res = 480
disp_drv.ver_res = 272
disp_drv.register()

# Regsiter SDL mouse driver
indev_drv = lv.indev_drv_t()
indev_drv.init()
indev_drv.type = lv.INDEV_TYPE.POINTER
indev_drv.read_cb = SDL.mouse_read
indev_drv.register()

fs_drv = lv.fs_drv_t()
fs_driver.fs_register(fs_drv, 'Z')

# Below: Taken from https://github.com/lvgl/lv_binding_micropython/blob/master/driver/js/imagetools.py#L22-L94

COLOR_SIZE = lv.color_t.__SIZE__
COLOR_IS_SWAPPED = hasattr(lv.color_t().ch,'green_h')

class lodepng_error(RuntimeError):
    def __init__(self, err):
        if type(err) is int:
            super().__init__(png.error_text(err))
        else:
            super().__init__(err)

# Parse PNG file header
# Taken from https://github.com/shibukawa/imagesize_py/blob/ffef30c1a4715c5acf90e8945ceb77f4a2ed2d45/imagesize.py#L63-L85

def get_png_info(decoder, src, header):
    # Only handle variable image types

    if lv.img.src_get_type(src) != lv.img.SRC.VARIABLE:
        return lv.RES.INV

    data = lv.img_dsc_t.__cast__(src).data
    if data == None:
        return lv.RES.INV

    png_header = bytes(data.__dereference__(24))

    if png_header.startswith(b'\211PNG\r\n\032\n'):
        if png_header[12:16] == b'IHDR':
            start = 16
        # Maybe this is for an older PNG version.
        else:
            start = 8
        try:
            width, height = ustruct.unpack(">LL", png_header[start:start+8])
        except ustruct.error:
            return lv.RES.INV
    else:
        return lv.RES.INV

    header.always_zero = 0
    header.w = width
    header.h = height
    header.cf = lv.img.CF.TRUE_COLOR_ALPHA

    return lv.RES.OK

def convert_rgba8888_to_bgra8888(img_view):
    for i in range(0, len(img_view), lv.color_t.__SIZE__):
        ch = lv.color_t.__cast__(img_view[i:i]).ch
        ch.red, ch.blue = ch.blue, ch.red

# Read and parse PNG file

def open_png(decoder, dsc):
    img_dsc = lv.img_dsc_t.__cast__(dsc.src)
    png_data = img_dsc.data
    png_size = img_dsc.data_size
    png_decoded = png.C_Pointer()
    png_width = png.C_Pointer()
    png_height = png.C_Pointer()
    error = png.decode32(png_decoded, png_width, png_height, png_data, png_size)
    if error:
        raise lodepng_error(error)
    img_size = png_width.int_val * png_height.int_val * 4
    img_data = png_decoded.ptr_val
    img_view = img_data.__dereference__(img_size)

    if COLOR_SIZE == 4:
        convert_rgba8888_to_bgra8888(img_view)
    else:
        raise lodepng_error("Error: Color mode not supported yet!")

    dsc.img_data = img_data
    return lv.RES.OK

# Above: Taken from https://github.com/lvgl/lv_binding_micropython/blob/master/driver/js/imagetools.py#L22-L94

decoder = lv.img.decoder_create()
decoder.info_cb = get_png_info
decoder.open_cb = open_png

def anim_x_cb(obj, v):
    obj.set_x(v)

def anim_y_cb(obj, v):
    obj.set_y(v)

def anim_width_cb(obj, v):
    obj.set_width(v)

def anim_height_cb(obj, v):
    obj.set_height(v)

def anim_img_zoom_cb(obj, v):
    obj.set_zoom(v)

def anim_img_rotate_cb(obj, v):
    obj.set_angle(v)

global_font_cache = {}
def test_font(font_family, font_size):
    global global_font_cache
    if font_family + str(font_size) in global_font_cache:
        return global_font_cache[font_family + str(font_size)]
    if font_size % 2:
        candidates = [
            (font_family, font_size),
            (font_family, font_size-font_size%2),
            (font_family, font_size+font_size%2),
            ("montserrat", font_size-font_size%2),
            ("montserrat", font_size+font_size%2),
            ("montserrat", 16)
        ]
    else:
        candidates = [
            (font_family, font_size),
            ("montserrat", font_size),
            ("montserrat", 16)
        ]
    for (family, size) in candidates:
        try:
            if eval(f'lv.font_{family}_{size}'):
                global_font_cache[font_family + str(font_size)] = eval(f'lv.font_{family}_{size}')
                if family != font_family or size != font_size:
                    print(f'WARNING: lv.font_{family}_{size} is used!')
                return eval(f'lv.font_{family}_{size}')
        except AttributeError:
            try:
                load_font = lv.font_load(f"Z:MicroPython/lv_font_{family}_{size}.fnt")
                global_font_cache[font_family + str(font_size)] = load_font
                return load_font
            except:
                if family == font_family and size == font_size:
                    print(f'WARNING: lv.font_{family}_{size} is NOT supported!')

global_image_cache = {}
def load_image(file):
    global global_image_cache
    if file in global_image_cache:
        return global_image_cache[file]
    try:
        with open(file,'rb') as f:
            data = f.read()
    except:
        print(f'Could not open {file}')
        sys.exit()

    img = lv.img_dsc_t({
        'data_size': len(data),
        'data': data
    })
    global_image_cache[file] = img
    return img

def calendar_event_handler(e,obj):
    code = e.get_code()

    if code == lv.EVENT.VALUE_CHANGED:
        source = e.get_current_target()
        date = lv.calendar_date_t()
        if source.get_pressed_date(date) == lv.RES.OK:
            source.set_highlighted_dates([date], 1)

def spinbox_increment_event_cb(e, obj):
    code = e.get_code()
    if code == lv.EVENT.SHORT_CLICKED or code == lv.EVENT.LONG_PRESSED_REPEAT:
        obj.increment()
def spinbox_decrement_event_cb(e, obj):
    code = e.get_code()
    if code == lv.EVENT.SHORT_CLICKED or code == lv.EVENT.LONG_PRESSED_REPEAT:
        obj.decrement()

def digital_clock_cb(timer, obj, current_time, show_second, use_ampm):
    hour = int(current_time[0])
    minute = int(current_time[1])
    second = int(current_time[2])
    ampm = current_time[3]
    second = second + 1
    if second == 60:
        second = 0
        minute = minute + 1
        if minute == 60:
            minute = 0
            hour = hour + 1
            if use_ampm:
                if hour == 12:
                    if ampm == 'AM':
                        ampm = 'PM'
                    elif ampm == 'PM':
                        ampm = 'AM'
                if hour > 12:
                    hour = hour % 12
    hour = hour % 24
    if use_ampm:
        if show_second:
            obj.set_text("%02d:%02d:%02d %s" %(hour, minute, second, ampm))
        else:
            obj.set_text("%02d:%02d %s" %(hour, minute, ampm))
    else:
        if show_second:
            obj.set_text("%02d:%02d:%02d" %(hour, minute, second))
        else:
            obj.set_text("%02d:%02d" %(hour, minute))
    current_time[0] = hour
    current_time[1] = minute
    current_time[2] = second
    current_time[3] = ampm

def analog_clock_cb(timer, obj):
    datetime = time.localtime()
    hour = datetime[3]
    if hour >= 12: hour = hour - 12
    obj.set_time(hour, datetime[4], datetime[5])

def datetext_event_handler(e, obj):
    code = e.get_code()
    target = e.get_target()
    if code == lv.EVENT.FOCUSED:
        if obj is None:
            bg = lv.layer_top()
            bg.add_flag(lv.obj.FLAG.CLICKABLE)
            obj = lv.calendar(bg)
            scr = target.get_screen()
            scr_height = scr.get_height()
            scr_width = scr.get_width()
            obj.set_size(int(scr_width * 0.8), int(scr_height * 0.8))
            datestring = target.get_text()
            year = int(datestring.split('/')[0])
            month = int(datestring.split('/')[1])
            day = int(datestring.split('/')[2])
            obj.set_showed_date(year, month)
            highlighted_days=[lv.calendar_date_t({'year':year, 'month':month, 'day':day})]
            obj.set_highlighted_dates(highlighted_days, 1)
            obj.align(lv.ALIGN.CENTER, 0, 0)
            lv.calendar_header_arrow(obj)
            obj.add_event_cb(lambda e: datetext_calendar_event_handler(e, target), lv.EVENT.ALL, None)
            scr.update_layout()

def datetext_calendar_event_handler(e, obj):
    code = e.get_code()
    target = e.get_current_target()
    if code == lv.EVENT.VALUE_CHANGED:
        date = lv.calendar_date_t()
        if target.get_pressed_date(date) == lv.RES.OK:
            obj.set_text(f"{date.year}/{date.month}/{date.day}")
            bg = lv.layer_top()
            bg.clear_flag(lv.obj.FLAG.CLICKABLE)
            bg.set_style_bg_opa(lv.OPA.TRANSP, 0)
            target.delete()

def home_screen_ta_event_cb(e,kb):
    code = e.get_code()
    ta = e.get_target()
    if code == lv.EVENT.FOCUSED:
        kb.set_textarea(ta)
        kb.move_foreground()
        kb.clear_flag(lv.obj.FLAG.HIDDEN)

    if code == lv.EVENT.DEFOCUSED:
        kb.set_textarea(None)
        kb.move_background()
        kb.add_flag(lv.obj.FLAG.HIDDEN)

def information_screen_ta_event_cb(e,kb):
    code = e.get_code()
    ta = e.get_target()
    if code == lv.EVENT.FOCUSED:
        kb.set_textarea(ta)
        kb.move_foreground()
        kb.clear_flag(lv.obj.FLAG.HIDDEN)

    if code == lv.EVENT.DEFOCUSED:
        kb.set_textarea(None)
        kb.move_background()
        kb.add_flag(lv.obj.FLAG.HIDDEN)

def instant_picture_ta_event_cb(e,kb):
    code = e.get_code()
    ta = e.get_target()
    if code == lv.EVENT.FOCUSED:
        kb.set_textarea(ta)
        kb.move_foreground()
        kb.clear_flag(lv.obj.FLAG.HIDDEN)

    if code == lv.EVENT.DEFOCUSED:
        kb.set_textarea(None)
        kb.move_background()
        kb.add_flag(lv.obj.FLAG.HIDDEN)

def example_page1_ta_event_cb(e,kb):
    code = e.get_code()
    ta = e.get_target()
    if code == lv.EVENT.FOCUSED:
        kb.set_textarea(ta)
        kb.move_foreground()
        kb.clear_flag(lv.obj.FLAG.HIDDEN)

    if code == lv.EVENT.DEFOCUSED:
        kb.set_textarea(None)
        kb.move_background()
        kb.add_flag(lv.obj.FLAG.HIDDEN)

def example_page2_ta_event_cb(e,kb):
    code = e.get_code()
    ta = e.get_target()
    if code == lv.EVENT.FOCUSED:
        kb.set_textarea(ta)
        kb.move_foreground()
        kb.clear_flag(lv.obj.FLAG.HIDDEN)

    if code == lv.EVENT.DEFOCUSED:
        kb.set_textarea(None)
        kb.move_background()
        kb.add_flag(lv.obj.FLAG.HIDDEN)

def introduction_page_ta_event_cb(e,kb):
    code = e.get_code()
    ta = e.get_target()
    if code == lv.EVENT.FOCUSED:
        kb.set_textarea(ta)
        kb.move_foreground()
        kb.clear_flag(lv.obj.FLAG.HIDDEN)

    if code == lv.EVENT.DEFOCUSED:
        kb.set_textarea(None)
        kb.move_background()
        kb.add_flag(lv.obj.FLAG.HIDDEN)

# Create home_screen
home_screen = lv.obj()
home_screen.set_size(480, 272)
home_screen.set_scrollbar_mode(lv.SCROLLBAR_MODE.OFF)
# Set style for home_screen, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
home_screen.set_style_bg_opa(255, lv.PART.MAIN|lv.STATE.DEFAULT)
home_screen.set_style_bg_color(lv.color_hex(0xaa6161), lv.PART.MAIN|lv.STATE.DEFAULT)
home_screen.set_style_bg_img_src(load_image(r"/Users/jacinto/GUI-Guider-Projects/BUGsUI/generated/MicroPython/background_480_272.png"), lv.PART.MAIN|lv.STATE.DEFAULT)
home_screen.set_style_bg_img_opa(255, lv.PART.MAIN|lv.STATE.DEFAULT)

# Create home_screen_information_btn
home_screen_information_btn = lv.btn(home_screen)
home_screen_information_btn_label = lv.label(home_screen_information_btn)
home_screen_information_btn_label.set_text("")
home_screen_information_btn_label.set_long_mode(lv.label.LONG.WRAP)
home_screen_information_btn_label.align(lv.ALIGN.CENTER, 0, 0)
home_screen_information_btn.set_style_pad_all(0, lv.STATE.DEFAULT)
home_screen_information_btn.set_pos(91, 79)
home_screen_information_btn.set_size(104, 91)
home_screen_information_btn.set_scrollbar_mode(lv.SCROLLBAR_MODE.OFF)
# Set style for home_screen_information_btn, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
home_screen_information_btn.set_style_bg_opa(255, lv.PART.MAIN|lv.STATE.DEFAULT)
home_screen_information_btn.set_style_bg_color(lv.color_hex(0x2195f6), lv.PART.MAIN|lv.STATE.DEFAULT)
home_screen_information_btn.set_style_border_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
home_screen_information_btn.set_style_radius(5, lv.PART.MAIN|lv.STATE.DEFAULT)
home_screen_information_btn.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
home_screen_information_btn.set_style_bg_img_src(load_image(r"/Users/jacinto/GUI-Guider-Projects/BUGsUI/generated/MicroPython/setting1_104_91.png"), lv.PART.MAIN|lv.STATE.DEFAULT)
home_screen_information_btn.set_style_bg_img_opa(255, lv.PART.MAIN|lv.STATE.DEFAULT)
home_screen_information_btn.set_style_text_color(lv.color_hex(0xffffff), lv.PART.MAIN|lv.STATE.DEFAULT)
home_screen_information_btn.set_style_text_font(test_font("montserratMedium", 16), lv.PART.MAIN|lv.STATE.DEFAULT)
home_screen_information_btn.set_style_text_align(lv.TEXT_ALIGN.CENTER, lv.PART.MAIN|lv.STATE.DEFAULT)

# Create home_screen_display_btn
home_screen_display_btn = lv.btn(home_screen)
home_screen_display_btn_label = lv.label(home_screen_display_btn)
home_screen_display_btn_label.set_text("")
home_screen_display_btn_label.set_long_mode(lv.label.LONG.WRAP)
home_screen_display_btn_label.align(lv.ALIGN.CENTER, 0, 0)
home_screen_display_btn.set_style_pad_all(0, lv.STATE.DEFAULT)
home_screen_display_btn.set_pos(279, 67)
home_screen_display_btn.set_size(215, 115)
home_screen_display_btn.set_scrollbar_mode(lv.SCROLLBAR_MODE.OFF)
# Set style for home_screen_display_btn, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
home_screen_display_btn.set_style_bg_opa(0, lv.PART.MAIN|lv.STATE.DEFAULT)
home_screen_display_btn.set_style_border_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
home_screen_display_btn.set_style_radius(5, lv.PART.MAIN|lv.STATE.DEFAULT)
home_screen_display_btn.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
home_screen_display_btn.set_style_bg_img_src(load_image(r"/Users/jacinto/GUI-Guider-Projects/BUGsUI/generated/MicroPython/ant_button_215_115.png"), lv.PART.MAIN|lv.STATE.DEFAULT)
home_screen_display_btn.set_style_bg_img_opa(255, lv.PART.MAIN|lv.STATE.DEFAULT)
home_screen_display_btn.set_style_text_color(lv.color_hex(0xffffff), lv.PART.MAIN|lv.STATE.DEFAULT)
home_screen_display_btn.set_style_text_font(test_font("montserratMedium", 16), lv.PART.MAIN|lv.STATE.DEFAULT)
home_screen_display_btn.set_style_text_align(lv.TEXT_ALIGN.CENTER, lv.PART.MAIN|lv.STATE.DEFAULT)

# Create home_screen_information_label
home_screen_information_label = lv.label(home_screen)
home_screen_information_label.set_text("information")
home_screen_information_label.set_long_mode(lv.label.LONG.WRAP)
home_screen_information_label.set_pos(73, 182)
home_screen_information_label.set_size(140, 16)
home_screen_information_label.set_scrollbar_mode(lv.SCROLLBAR_MODE.OFF)
# Set style for home_screen_information_label, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
home_screen_information_label.set_style_border_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
home_screen_information_label.set_style_radius(0, lv.PART.MAIN|lv.STATE.DEFAULT)
home_screen_information_label.set_style_text_color(lv.color_hex(0x000000), lv.PART.MAIN|lv.STATE.DEFAULT)
home_screen_information_label.set_style_text_font(test_font("montserratMedium", 16), lv.PART.MAIN|lv.STATE.DEFAULT)
home_screen_information_label.set_style_text_letter_space(2, lv.PART.MAIN|lv.STATE.DEFAULT)
home_screen_information_label.set_style_text_line_space(0, lv.PART.MAIN|lv.STATE.DEFAULT)
home_screen_information_label.set_style_text_align(lv.TEXT_ALIGN.CENTER, lv.PART.MAIN|lv.STATE.DEFAULT)
home_screen_information_label.set_style_bg_opa(0, lv.PART.MAIN|lv.STATE.DEFAULT)
home_screen_information_label.set_style_pad_top(0, lv.PART.MAIN|lv.STATE.DEFAULT)
home_screen_information_label.set_style_pad_right(0, lv.PART.MAIN|lv.STATE.DEFAULT)
home_screen_information_label.set_style_pad_bottom(0, lv.PART.MAIN|lv.STATE.DEFAULT)
home_screen_information_label.set_style_pad_left(0, lv.PART.MAIN|lv.STATE.DEFAULT)
home_screen_information_label.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)

# Create home_screen_display_label
home_screen_display_label = lv.label(home_screen)
home_screen_display_label.set_text("Find Ant!")
home_screen_display_label.set_long_mode(lv.label.LONG.WRAP)
home_screen_display_label.set_pos(279, 184)
home_screen_display_label.set_size(111, 14)
home_screen_display_label.set_scrollbar_mode(lv.SCROLLBAR_MODE.OFF)
# Set style for home_screen_display_label, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
home_screen_display_label.set_style_border_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
home_screen_display_label.set_style_radius(0, lv.PART.MAIN|lv.STATE.DEFAULT)
home_screen_display_label.set_style_text_color(lv.color_hex(0x000000), lv.PART.MAIN|lv.STATE.DEFAULT)
home_screen_display_label.set_style_text_font(test_font("montserratMedium", 16), lv.PART.MAIN|lv.STATE.DEFAULT)
home_screen_display_label.set_style_text_letter_space(2, lv.PART.MAIN|lv.STATE.DEFAULT)
home_screen_display_label.set_style_text_line_space(0, lv.PART.MAIN|lv.STATE.DEFAULT)
home_screen_display_label.set_style_text_align(lv.TEXT_ALIGN.CENTER, lv.PART.MAIN|lv.STATE.DEFAULT)
home_screen_display_label.set_style_bg_opa(0, lv.PART.MAIN|lv.STATE.DEFAULT)
home_screen_display_label.set_style_pad_top(0, lv.PART.MAIN|lv.STATE.DEFAULT)
home_screen_display_label.set_style_pad_right(0, lv.PART.MAIN|lv.STATE.DEFAULT)
home_screen_display_label.set_style_pad_bottom(0, lv.PART.MAIN|lv.STATE.DEFAULT)
home_screen_display_label.set_style_pad_left(0, lv.PART.MAIN|lv.STATE.DEFAULT)
home_screen_display_label.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)

home_screen.update_layout()
# Create information_screen
information_screen = lv.obj()
information_screen.set_size(480, 272)
information_screen.set_scrollbar_mode(lv.SCROLLBAR_MODE.OFF)
# Set style for information_screen, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
information_screen.set_style_bg_opa(0, lv.PART.MAIN|lv.STATE.DEFAULT)
information_screen.set_style_bg_img_src(load_image(r"/Users/jacinto/GUI-Guider-Projects/BUGsUI/generated/MicroPython/background_480_272.png"), lv.PART.MAIN|lv.STATE.DEFAULT)
information_screen.set_style_bg_img_opa(255, lv.PART.MAIN|lv.STATE.DEFAULT)
information_screen.set_style_bg_img_recolor(lv.color_hex(0x9893A7), lv.PART.MAIN|lv.STATE.DEFAULT)
information_screen.set_style_bg_img_recolor_opa(142, lv.PART.MAIN|lv.STATE.DEFAULT)

# Create information_screen_BACK_btn1
information_screen_BACK_btn1 = lv.btn(information_screen)
information_screen_BACK_btn1_label = lv.label(information_screen_BACK_btn1)
information_screen_BACK_btn1_label.set_text("BACK")
information_screen_BACK_btn1_label.set_long_mode(lv.label.LONG.WRAP)
information_screen_BACK_btn1_label.align(lv.ALIGN.CENTER, 0, 0)
information_screen_BACK_btn1.set_style_pad_all(0, lv.STATE.DEFAULT)
information_screen_BACK_btn1.set_pos(70, 173)
information_screen_BACK_btn1.set_size(60, 100)
information_screen_BACK_btn1.set_scrollbar_mode(lv.SCROLLBAR_MODE.OFF)
# Set style for information_screen_BACK_btn1, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
information_screen_BACK_btn1.set_style_bg_opa(195, lv.PART.MAIN|lv.STATE.DEFAULT)
information_screen_BACK_btn1.set_style_bg_color(lv.color_hex(0x9893A7), lv.PART.MAIN|lv.STATE.DEFAULT)
information_screen_BACK_btn1.set_style_border_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
information_screen_BACK_btn1.set_style_radius(5, lv.PART.MAIN|lv.STATE.DEFAULT)
information_screen_BACK_btn1.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
information_screen_BACK_btn1.set_style_text_color(lv.color_hex(0xffffff), lv.PART.MAIN|lv.STATE.DEFAULT)
information_screen_BACK_btn1.set_style_text_font(test_font("montserratMedium", 16), lv.PART.MAIN|lv.STATE.DEFAULT)
information_screen_BACK_btn1.set_style_text_align(lv.TEXT_ALIGN.CENTER, lv.PART.MAIN|lv.STATE.DEFAULT)

# Create information_screen_abousus_btn
information_screen_abousus_btn = lv.btn(information_screen)
information_screen_abousus_btn_label = lv.label(information_screen_abousus_btn)
information_screen_abousus_btn_label.set_text("about \nus")
information_screen_abousus_btn_label.set_long_mode(lv.label.LONG.WRAP)
information_screen_abousus_btn_label.align(lv.ALIGN.CENTER, 0, 0)
information_screen_abousus_btn.set_style_pad_all(0, lv.STATE.DEFAULT)
information_screen_abousus_btn.set_pos(210, 133)
information_screen_abousus_btn.set_size(60, 140)
information_screen_abousus_btn.set_scrollbar_mode(lv.SCROLLBAR_MODE.OFF)
# Set style for information_screen_abousus_btn, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
information_screen_abousus_btn.set_style_bg_opa(216, lv.PART.MAIN|lv.STATE.DEFAULT)
information_screen_abousus_btn.set_style_bg_color(lv.color_hex(0x9893A7), lv.PART.MAIN|lv.STATE.DEFAULT)
information_screen_abousus_btn.set_style_border_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
information_screen_abousus_btn.set_style_radius(5, lv.PART.MAIN|lv.STATE.DEFAULT)
information_screen_abousus_btn.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
information_screen_abousus_btn.set_style_text_color(lv.color_hex(0xffffff), lv.PART.MAIN|lv.STATE.DEFAULT)
information_screen_abousus_btn.set_style_text_font(test_font("montserratMedium", 16), lv.PART.MAIN|lv.STATE.DEFAULT)
information_screen_abousus_btn.set_style_text_align(lv.TEXT_ALIGN.CENTER, lv.PART.MAIN|lv.STATE.DEFAULT)

# Create information_screen_seemore_btn
information_screen_seemore_btn = lv.btn(information_screen)
information_screen_seemore_btn_label = lv.label(information_screen_seemore_btn)
information_screen_seemore_btn_label.set_text("see\nmore\n\n")
information_screen_seemore_btn_label.set_long_mode(lv.label.LONG.WRAP)
information_screen_seemore_btn_label.align(lv.ALIGN.CENTER, 0, 0)
information_screen_seemore_btn.set_style_pad_all(0, lv.STATE.DEFAULT)
information_screen_seemore_btn.set_pos(350, 93)
information_screen_seemore_btn.set_size(60, 180)
information_screen_seemore_btn.set_scrollbar_mode(lv.SCROLLBAR_MODE.OFF)
# Set style for information_screen_seemore_btn, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
information_screen_seemore_btn.set_style_bg_opa(216, lv.PART.MAIN|lv.STATE.DEFAULT)
information_screen_seemore_btn.set_style_bg_color(lv.color_hex(0x9893A7), lv.PART.MAIN|lv.STATE.DEFAULT)
information_screen_seemore_btn.set_style_border_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
information_screen_seemore_btn.set_style_radius(5, lv.PART.MAIN|lv.STATE.DEFAULT)
information_screen_seemore_btn.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
information_screen_seemore_btn.set_style_text_color(lv.color_hex(0xffffff), lv.PART.MAIN|lv.STATE.DEFAULT)
information_screen_seemore_btn.set_style_text_font(test_font("montserratMedium", 16), lv.PART.MAIN|lv.STATE.DEFAULT)
information_screen_seemore_btn.set_style_text_align(lv.TEXT_ALIGN.CENTER, lv.PART.MAIN|lv.STATE.DEFAULT)

# Create information_screen_btn_5
information_screen_btn_5 = lv.btn(information_screen)
information_screen_btn_5_label = lv.label(information_screen_btn_5)
information_screen_btn_5_label.set_text("")
information_screen_btn_5_label.set_long_mode(lv.label.LONG.WRAP)
information_screen_btn_5_label.align(lv.ALIGN.CENTER, 0, 0)
information_screen_btn_5.set_style_pad_all(0, lv.STATE.DEFAULT)
information_screen_btn_5.set_pos(320, 1)
information_screen_btn_5.set_size(35, 50)
information_screen_btn_5.set_scrollbar_mode(lv.SCROLLBAR_MODE.OFF)
# Set style for information_screen_btn_5, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
information_screen_btn_5.set_style_bg_opa(255, lv.PART.MAIN|lv.STATE.DEFAULT)
information_screen_btn_5.set_style_bg_color(lv.color_hex(0xd4d2da), lv.PART.MAIN|lv.STATE.DEFAULT)
information_screen_btn_5.set_style_border_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
information_screen_btn_5.set_style_radius(5, lv.PART.MAIN|lv.STATE.DEFAULT)
information_screen_btn_5.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
information_screen_btn_5.set_style_text_color(lv.color_hex(0xffffff), lv.PART.MAIN|lv.STATE.DEFAULT)
information_screen_btn_5.set_style_text_font(test_font("montserratMedium", 16), lv.PART.MAIN|lv.STATE.DEFAULT)
information_screen_btn_5.set_style_text_align(lv.TEXT_ALIGN.CENTER, lv.PART.MAIN|lv.STATE.DEFAULT)

# Create information_screen_btn_6
information_screen_btn_6 = lv.btn(information_screen)
information_screen_btn_6_label = lv.label(information_screen_btn_6)
information_screen_btn_6_label.set_text("")
information_screen_btn_6_label.set_long_mode(lv.label.LONG.WRAP)
information_screen_btn_6_label.align(lv.ALIGN.CENTER, 0, 0)
information_screen_btn_6.set_style_pad_all(0, lv.STATE.DEFAULT)
information_screen_btn_6.set_pos(177, 1)
information_screen_btn_6.set_size(35, 70)
information_screen_btn_6.set_scrollbar_mode(lv.SCROLLBAR_MODE.OFF)
# Set style for information_screen_btn_6, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
information_screen_btn_6.set_style_bg_opa(255, lv.PART.MAIN|lv.STATE.DEFAULT)
information_screen_btn_6.set_style_bg_color(lv.color_hex(0xd4d2da), lv.PART.MAIN|lv.STATE.DEFAULT)
information_screen_btn_6.set_style_border_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
information_screen_btn_6.set_style_radius(5, lv.PART.MAIN|lv.STATE.DEFAULT)
information_screen_btn_6.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
information_screen_btn_6.set_style_text_color(lv.color_hex(0xffffff), lv.PART.MAIN|lv.STATE.DEFAULT)
information_screen_btn_6.set_style_text_font(test_font("montserratMedium", 16), lv.PART.MAIN|lv.STATE.DEFAULT)
information_screen_btn_6.set_style_text_align(lv.TEXT_ALIGN.CENTER, lv.PART.MAIN|lv.STATE.DEFAULT)

# Create information_screen_btn_7
information_screen_btn_7 = lv.btn(information_screen)
information_screen_btn_7_label = lv.label(information_screen_btn_7)
information_screen_btn_7_label.set_text("")
information_screen_btn_7_label.set_long_mode(lv.label.LONG.WRAP)
information_screen_btn_7_label.align(lv.ALIGN.CENTER, 0, 0)
information_screen_btn_7.set_style_pad_all(0, lv.STATE.DEFAULT)
information_screen_btn_7.set_pos(31, 1)
information_screen_btn_7.set_size(35, 90)
information_screen_btn_7.set_scrollbar_mode(lv.SCROLLBAR_MODE.OFF)
# Set style for information_screen_btn_7, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
information_screen_btn_7.set_style_bg_opa(255, lv.PART.MAIN|lv.STATE.DEFAULT)
information_screen_btn_7.set_style_bg_color(lv.color_hex(0xd4d2da), lv.PART.MAIN|lv.STATE.DEFAULT)
information_screen_btn_7.set_style_border_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
information_screen_btn_7.set_style_radius(5, lv.PART.MAIN|lv.STATE.DEFAULT)
information_screen_btn_7.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
information_screen_btn_7.set_style_text_color(lv.color_hex(0xffffff), lv.PART.MAIN|lv.STATE.DEFAULT)
information_screen_btn_7.set_style_text_font(test_font("montserratMedium", 16), lv.PART.MAIN|lv.STATE.DEFAULT)
information_screen_btn_7.set_style_text_align(lv.TEXT_ALIGN.CENTER, lv.PART.MAIN|lv.STATE.DEFAULT)

information_screen.update_layout()
# Create instant_picture
instant_picture = lv.obj()
instant_picture.set_size(480, 272)
instant_picture.set_scrollbar_mode(lv.SCROLLBAR_MODE.OFF)
# Set style for instant_picture, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
instant_picture.set_style_bg_opa(0, lv.PART.MAIN|lv.STATE.DEFAULT)
instant_picture.set_style_bg_img_src(load_image(r"/Users/jacinto/GUI-Guider-Projects/BUGsUI/generated/MicroPython/background_480_272.png"), lv.PART.MAIN|lv.STATE.DEFAULT)
instant_picture.set_style_bg_img_opa(255, lv.PART.MAIN|lv.STATE.DEFAULT)
instant_picture.set_style_bg_img_recolor(lv.color_hex(0x67ff00), lv.PART.MAIN|lv.STATE.DEFAULT)
instant_picture.set_style_bg_img_recolor_opa(34, lv.PART.MAIN|lv.STATE.DEFAULT)

# Create instant_picture_img_1
instant_picture_img_1 = lv.img(instant_picture)
instant_picture_img_1.set_src(load_image(r"/Users/jacinto/GUI-Guider-Projects/BUGsUI/generated/MicroPython/Direction_645_322.png"))
instant_picture_img_1.add_flag(lv.obj.FLAG.CLICKABLE)
instant_picture_img_1.set_pivot(309,156)
instant_picture_img_1.set_angle(0)
instant_picture_img_1.set_pos(-68, -25)
instant_picture_img_1.set_size(645, 322)
instant_picture_img_1.set_scrollbar_mode(lv.SCROLLBAR_MODE.OFF)
# Set style for instant_picture_img_1, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
instant_picture_img_1.set_style_img_opa(255, lv.PART.MAIN|lv.STATE.DEFAULT)

# Create instant_picture_BACK_btn2
instant_picture_BACK_btn2 = lv.btn(instant_picture)
instant_picture_BACK_btn2_label = lv.label(instant_picture_BACK_btn2)
instant_picture_BACK_btn2_label.set_text("BACK")
instant_picture_BACK_btn2_label.set_long_mode(lv.label.LONG.WRAP)
instant_picture_BACK_btn2_label.align(lv.ALIGN.CENTER, 0, 0)
instant_picture_BACK_btn2.set_style_pad_all(0, lv.STATE.DEFAULT)
instant_picture_BACK_btn2.set_pos(0, 17)
instant_picture_BACK_btn2.set_size(118, 35)
instant_picture_BACK_btn2.set_scrollbar_mode(lv.SCROLLBAR_MODE.OFF)
#Update pos for widget instant_picture_BACK_btn2
instant_picture_BACK_btn2.update_layout()
#Write animation: instant_picture_BACK_btn2 move in x direction
instant_picture_BACK_btn2_x = lv.anim_t()
instant_picture_BACK_btn2_x.init()
instant_picture_BACK_btn2_x.set_var(instant_picture_BACK_btn2)
instant_picture_BACK_btn2_x.set_time(1000)
instant_picture_BACK_btn2_x.set_custom_exec_cb(lambda e,val: anim_x_cb(instant_picture_BACK_btn2,val))
instant_picture_BACK_btn2_x.set_values(instant_picture_BACK_btn2.get_x(), 0)
instant_picture_BACK_btn2_x.set_path_cb(lv.anim_t.path_linear)
instant_picture_BACK_btn2_x.start()
#Write animation: instant_picture_BACK_btn2 move in y direction
instant_picture_BACK_btn2_y = lv.anim_t()
instant_picture_BACK_btn2_y.set_var(instant_picture_BACK_btn2)
instant_picture_BACK_btn2_y.set_time(1000)
instant_picture_BACK_btn2_y.set_custom_exec_cb(lambda e,val: anim_y_cb(instant_picture_BACK_btn2,val))
instant_picture_BACK_btn2_y.set_values(instant_picture_BACK_btn2.get_y(), 0)
instant_picture_BACK_btn2_y.set_path_cb(lv.anim_t.path_linear)
instant_picture_BACK_btn2_y.start()
# Set style for instant_picture_BACK_btn2, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
instant_picture_BACK_btn2.set_style_bg_opa(195, lv.PART.MAIN|lv.STATE.DEFAULT)
instant_picture_BACK_btn2.set_style_bg_color(lv.color_hex(0x9893A7), lv.PART.MAIN|lv.STATE.DEFAULT)
instant_picture_BACK_btn2.set_style_border_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
instant_picture_BACK_btn2.set_style_radius(5, lv.PART.MAIN|lv.STATE.DEFAULT)
instant_picture_BACK_btn2.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
instant_picture_BACK_btn2.set_style_text_color(lv.color_hex(0xffffff), lv.PART.MAIN|lv.STATE.DEFAULT)
instant_picture_BACK_btn2.set_style_text_font(test_font("montserratMedium", 16), lv.PART.MAIN|lv.STATE.DEFAULT)
instant_picture_BACK_btn2.set_style_text_align(lv.TEXT_ALIGN.CENTER, lv.PART.MAIN|lv.STATE.DEFAULT)

# Create instant_picture_img_2
instant_picture_img_2 = lv.img(instant_picture)
instant_picture_img_2.set_src(load_image(r"/Users/jacinto/GUI-Guider-Projects/BUGsUI/generated/MicroPython/arrow_45_105.png"))
instant_picture_img_2.add_flag(lv.obj.FLAG.CLICKABLE)
instant_picture_img_2.set_pivot(24,50)
instant_picture_img_2.set_angle(0)
instant_picture_img_2.set_pos(218, 84)
instant_picture_img_2.set_size(45, 105)
instant_picture_img_2.set_scrollbar_mode(lv.SCROLLBAR_MODE.OFF)
# Set style for instant_picture_img_2, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
instant_picture_img_2.set_style_img_opa(255, lv.PART.MAIN|lv.STATE.DEFAULT)

instant_picture.update_layout()
# Create example_page1
example_page1 = lv.obj()
example_page1.set_size(480, 272)
example_page1.set_scrollbar_mode(lv.SCROLLBAR_MODE.OFF)
# Set style for example_page1, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
example_page1.set_style_bg_opa(0, lv.PART.MAIN|lv.STATE.DEFAULT)
example_page1.set_style_bg_img_src(load_image(r"/Users/jacinto/GUI-Guider-Projects/BUGsUI/generated/MicroPython/example_page1_480_272.png"), lv.PART.MAIN|lv.STATE.DEFAULT)
example_page1.set_style_bg_img_opa(255, lv.PART.MAIN|lv.STATE.DEFAULT)

# Create example_page1_BACK_btn3
example_page1_BACK_btn3 = lv.btn(example_page1)
example_page1_BACK_btn3_label = lv.label(example_page1_BACK_btn3)
example_page1_BACK_btn3_label.set_text("BACK")
example_page1_BACK_btn3_label.set_long_mode(lv.label.LONG.WRAP)
example_page1_BACK_btn3_label.align(lv.ALIGN.CENTER, 0, 0)
example_page1_BACK_btn3.set_style_pad_all(0, lv.STATE.DEFAULT)
example_page1_BACK_btn3.set_pos(0, 17)
example_page1_BACK_btn3.set_size(117, 35)
example_page1_BACK_btn3.set_scrollbar_mode(lv.SCROLLBAR_MODE.OFF)
# Set style for example_page1_BACK_btn3, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
example_page1_BACK_btn3.set_style_bg_opa(195, lv.PART.MAIN|lv.STATE.DEFAULT)
example_page1_BACK_btn3.set_style_bg_color(lv.color_hex(0x9893A7), lv.PART.MAIN|lv.STATE.DEFAULT)
example_page1_BACK_btn3.set_style_border_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
example_page1_BACK_btn3.set_style_radius(5, lv.PART.MAIN|lv.STATE.DEFAULT)
example_page1_BACK_btn3.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
example_page1_BACK_btn3.set_style_text_color(lv.color_hex(0xffffff), lv.PART.MAIN|lv.STATE.DEFAULT)
example_page1_BACK_btn3.set_style_text_font(test_font("montserratMedium", 16), lv.PART.MAIN|lv.STATE.DEFAULT)
example_page1_BACK_btn3.set_style_text_align(lv.TEXT_ALIGN.CENTER, lv.PART.MAIN|lv.STATE.DEFAULT)

# Create example_page1_MORE_btn
example_page1_MORE_btn = lv.btn(example_page1)
example_page1_MORE_btn_label = lv.label(example_page1_MORE_btn)
example_page1_MORE_btn_label.set_text("MORE")
example_page1_MORE_btn_label.set_long_mode(lv.label.LONG.WRAP)
example_page1_MORE_btn_label.align(lv.ALIGN.CENTER, 0, 0)
example_page1_MORE_btn.set_style_pad_all(0, lv.STATE.DEFAULT)
example_page1_MORE_btn.set_pos(362, 217)
example_page1_MORE_btn.set_size(117, 35)
example_page1_MORE_btn.set_scrollbar_mode(lv.SCROLLBAR_MODE.OFF)
# Set style for example_page1_MORE_btn, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
example_page1_MORE_btn.set_style_bg_opa(195, lv.PART.MAIN|lv.STATE.DEFAULT)
example_page1_MORE_btn.set_style_bg_color(lv.color_hex(0x9893A7), lv.PART.MAIN|lv.STATE.DEFAULT)
example_page1_MORE_btn.set_style_border_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
example_page1_MORE_btn.set_style_radius(5, lv.PART.MAIN|lv.STATE.DEFAULT)
example_page1_MORE_btn.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
example_page1_MORE_btn.set_style_text_color(lv.color_hex(0xffffff), lv.PART.MAIN|lv.STATE.DEFAULT)
example_page1_MORE_btn.set_style_text_font(test_font("montserratMedium", 16), lv.PART.MAIN|lv.STATE.DEFAULT)
example_page1_MORE_btn.set_style_text_align(lv.TEXT_ALIGN.CENTER, lv.PART.MAIN|lv.STATE.DEFAULT)

example_page1.update_layout()
# Create example_page2
example_page2 = lv.obj()
example_page2.set_size(480, 272)
example_page2.set_scrollbar_mode(lv.SCROLLBAR_MODE.OFF)
# Set style for example_page2, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
example_page2.set_style_bg_opa(0, lv.PART.MAIN|lv.STATE.DEFAULT)
example_page2.set_style_bg_img_src(load_image(r"/Users/jacinto/GUI-Guider-Projects/BUGsUI/generated/MicroPython/example_page2_480_272.png"), lv.PART.MAIN|lv.STATE.DEFAULT)
example_page2.set_style_bg_img_opa(255, lv.PART.MAIN|lv.STATE.DEFAULT)

# Create example_page2_BACK_btn4
example_page2_BACK_btn4 = lv.btn(example_page2)
example_page2_BACK_btn4_label = lv.label(example_page2_BACK_btn4)
example_page2_BACK_btn4_label.set_text("BACK")
example_page2_BACK_btn4_label.set_long_mode(lv.label.LONG.WRAP)
example_page2_BACK_btn4_label.align(lv.ALIGN.CENTER, 0, 0)
example_page2_BACK_btn4.set_style_pad_all(0, lv.STATE.DEFAULT)
example_page2_BACK_btn4.set_pos(0, 17)
example_page2_BACK_btn4.set_size(117, 35)
example_page2_BACK_btn4.set_scrollbar_mode(lv.SCROLLBAR_MODE.OFF)
# Set style for example_page2_BACK_btn4, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
example_page2_BACK_btn4.set_style_bg_opa(195, lv.PART.MAIN|lv.STATE.DEFAULT)
example_page2_BACK_btn4.set_style_bg_color(lv.color_hex(0x9893A7), lv.PART.MAIN|lv.STATE.DEFAULT)
example_page2_BACK_btn4.set_style_border_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
example_page2_BACK_btn4.set_style_radius(5, lv.PART.MAIN|lv.STATE.DEFAULT)
example_page2_BACK_btn4.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
example_page2_BACK_btn4.set_style_text_color(lv.color_hex(0xffffff), lv.PART.MAIN|lv.STATE.DEFAULT)
example_page2_BACK_btn4.set_style_text_font(test_font("montserratMedium", 16), lv.PART.MAIN|lv.STATE.DEFAULT)
example_page2_BACK_btn4.set_style_text_align(lv.TEXT_ALIGN.CENTER, lv.PART.MAIN|lv.STATE.DEFAULT)

example_page2.update_layout()
# Create introduction_page
introduction_page = lv.obj()
introduction_page.set_size(480, 272)
introduction_page.set_scrollbar_mode(lv.SCROLLBAR_MODE.OFF)
# Set style for introduction_page, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
introduction_page.set_style_bg_opa(0, lv.PART.MAIN|lv.STATE.DEFAULT)
introduction_page.set_style_bg_img_src(load_image(r"/Users/jacinto/GUI-Guider-Projects/BUGsUI/generated/MicroPython/background_480_272.png"), lv.PART.MAIN|lv.STATE.DEFAULT)
introduction_page.set_style_bg_img_opa(255, lv.PART.MAIN|lv.STATE.DEFAULT)
introduction_page.set_style_bg_img_recolor(lv.color_hex(0x000000), lv.PART.MAIN|lv.STATE.DEFAULT)
introduction_page.set_style_bg_img_recolor_opa(45, lv.PART.MAIN|lv.STATE.DEFAULT)

# Create introduction_page_BACK_btn5
introduction_page_BACK_btn5 = lv.btn(introduction_page)
introduction_page_BACK_btn5_label = lv.label(introduction_page_BACK_btn5)
introduction_page_BACK_btn5_label.set_text("BACK")
introduction_page_BACK_btn5_label.set_long_mode(lv.label.LONG.WRAP)
introduction_page_BACK_btn5_label.align(lv.ALIGN.CENTER, 0, 0)
introduction_page_BACK_btn5.set_style_pad_all(0, lv.STATE.DEFAULT)
introduction_page_BACK_btn5.set_pos(0, 17)
introduction_page_BACK_btn5.set_size(117, 35)
introduction_page_BACK_btn5.set_scrollbar_mode(lv.SCROLLBAR_MODE.OFF)
# Set style for introduction_page_BACK_btn5, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
introduction_page_BACK_btn5.set_style_bg_opa(195, lv.PART.MAIN|lv.STATE.DEFAULT)
introduction_page_BACK_btn5.set_style_bg_color(lv.color_hex(0x9893A7), lv.PART.MAIN|lv.STATE.DEFAULT)
introduction_page_BACK_btn5.set_style_border_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
introduction_page_BACK_btn5.set_style_radius(5, lv.PART.MAIN|lv.STATE.DEFAULT)
introduction_page_BACK_btn5.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
introduction_page_BACK_btn5.set_style_text_color(lv.color_hex(0xffffff), lv.PART.MAIN|lv.STATE.DEFAULT)
introduction_page_BACK_btn5.set_style_text_font(test_font("montserratMedium", 16), lv.PART.MAIN|lv.STATE.DEFAULT)
introduction_page_BACK_btn5.set_style_text_align(lv.TEXT_ALIGN.CENTER, lv.PART.MAIN|lv.STATE.DEFAULT)

# Create introduction_page_qrcode_1
introduction_page_qrcode_1 = lv.qrcode(introduction_page, 100, lv.color_hex(0x2C3224), lv.color_hex(0xffffff))
introduction_page_qrcode_1_data = "https://hackmd.io/@jacinto5940304/leopards"
introduction_page_qrcode_1.update(introduction_page_qrcode_1_data, len(introduction_page_qrcode_1_data))
introduction_page_qrcode_1.set_pos(190, 76)
introduction_page_qrcode_1.set_size(100, 100)

# Create introduction_page_label_1
introduction_page_label_1 = lv.label(introduction_page)
introduction_page_label_1.set_text("Scan to learn about our design concept")
introduction_page_label_1.set_long_mode(lv.label.LONG.WRAP)
introduction_page_label_1.set_pos(12, 193)
introduction_page_label_1.set_size(457, 21)
introduction_page_label_1.set_scrollbar_mode(lv.SCROLLBAR_MODE.OFF)
# Set style for introduction_page_label_1, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
introduction_page_label_1.set_style_border_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
introduction_page_label_1.set_style_radius(0, lv.PART.MAIN|lv.STATE.DEFAULT)
introduction_page_label_1.set_style_text_color(lv.color_hex(0x000000), lv.PART.MAIN|lv.STATE.DEFAULT)
introduction_page_label_1.set_style_text_font(test_font("montserratMedium", 16), lv.PART.MAIN|lv.STATE.DEFAULT)
introduction_page_label_1.set_style_text_letter_space(2, lv.PART.MAIN|lv.STATE.DEFAULT)
introduction_page_label_1.set_style_text_line_space(0, lv.PART.MAIN|lv.STATE.DEFAULT)
introduction_page_label_1.set_style_text_align(lv.TEXT_ALIGN.CENTER, lv.PART.MAIN|lv.STATE.DEFAULT)
introduction_page_label_1.set_style_bg_opa(0, lv.PART.MAIN|lv.STATE.DEFAULT)
introduction_page_label_1.set_style_pad_top(0, lv.PART.MAIN|lv.STATE.DEFAULT)
introduction_page_label_1.set_style_pad_right(0, lv.PART.MAIN|lv.STATE.DEFAULT)
introduction_page_label_1.set_style_pad_bottom(0, lv.PART.MAIN|lv.STATE.DEFAULT)
introduction_page_label_1.set_style_pad_left(0, lv.PART.MAIN|lv.STATE.DEFAULT)
introduction_page_label_1.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)

introduction_page.update_layout()

def home_screen_information_btn_event_handler(e):
    code = e.get_code()
    if (code == lv.EVENT.CLICKED):
        lv.scr_load_anim(information_screen, lv.SCR_LOAD_ANIM.OVER_TOP, 200, 200, False)

home_screen_information_btn.add_event_cb(lambda e: home_screen_information_btn_event_handler(e), lv.EVENT.ALL, None)

def home_screen_display_btn_event_handler(e):
    code = e.get_code()
    if (code == lv.EVENT.CLICKED):
        lv.scr_load_anim(instant_picture, lv.SCR_LOAD_ANIM.NONE, 200, 200, False)

home_screen_display_btn.add_event_cb(lambda e: home_screen_display_btn_event_handler(e), lv.EVENT.ALL, None)

def information_screen_event_handler(e):
    code = e.get_code()
    if (code == lv.EVENT.CLICKED):
        lv.scr_load_anim(home_screen, lv.SCR_LOAD_ANIM.NONE, 200, 200, False)

information_screen.add_event_cb(lambda e: information_screen_event_handler(e), lv.EVENT.ALL, None)

def information_screen_BACK_btn1_event_handler(e):
    code = e.get_code()
    if (code == lv.EVENT.CLICKED):
        lv.scr_load_anim(home_screen, lv.SCR_LOAD_ANIM.NONE, 200, 200, False)

information_screen_BACK_btn1.add_event_cb(lambda e: information_screen_BACK_btn1_event_handler(e), lv.EVENT.ALL, None)

def information_screen_abousus_btn_event_handler(e):
    code = e.get_code()
    if (code == lv.EVENT.CLICKED):
        lv.scr_load_anim(introduction_page, lv.SCR_LOAD_ANIM.NONE, 200, 200, False)

information_screen_abousus_btn.add_event_cb(lambda e: information_screen_abousus_btn_event_handler(e), lv.EVENT.ALL, None)

def information_screen_seemore_btn_event_handler(e):
    code = e.get_code()
    if (code == lv.EVENT.CLICKED):
        lv.scr_load_anim(example_page1, lv.SCR_LOAD_ANIM.NONE, 200, 200, False)

information_screen_seemore_btn.add_event_cb(lambda e: information_screen_seemore_btn_event_handler(e), lv.EVENT.ALL, None)

def instant_picture_BACK_btn2_event_handler(e):
    code = e.get_code()
    if (code == lv.EVENT.CLICKED):
        lv.scr_load_anim(home_screen, lv.SCR_LOAD_ANIM.NONE, 200, 200, False)

instant_picture_BACK_btn2.add_event_cb(lambda e: instant_picture_BACK_btn2_event_handler(e), lv.EVENT.ALL, None)

def example_page1_BACK_btn3_event_handler(e):
    code = e.get_code()
    if (code == lv.EVENT.CLICKED):
        lv.scr_load_anim(information_screen, lv.SCR_LOAD_ANIM.NONE, 200, 200, False)

example_page1_BACK_btn3.add_event_cb(lambda e: example_page1_BACK_btn3_event_handler(e), lv.EVENT.ALL, None)

def example_page1_MORE_btn_event_handler(e):
    code = e.get_code()
    if (code == lv.EVENT.CLICKED):
        lv.scr_load_anim(example_page2, lv.SCR_LOAD_ANIM.NONE, 200, 200, False)

example_page1_MORE_btn.add_event_cb(lambda e: example_page1_MORE_btn_event_handler(e), lv.EVENT.ALL, None)

def example_page2_BACK_btn4_event_handler(e):
    code = e.get_code()
    if (code == lv.EVENT.CLICKED):
        lv.scr_load_anim(example_page1, lv.SCR_LOAD_ANIM.NONE, 200, 200, False)

example_page2_BACK_btn4.add_event_cb(lambda e: example_page2_BACK_btn4_event_handler(e), lv.EVENT.ALL, None)

def introduction_page_BACK_btn5_event_handler(e):
    code = e.get_code()
    if (code == lv.EVENT.CLICKED):
        lv.scr_load_anim(information_screen, lv.SCR_LOAD_ANIM.NONE, 200, 200, False)

introduction_page_BACK_btn5.add_event_cb(lambda e: introduction_page_BACK_btn5_event_handler(e), lv.EVENT.ALL, None)

# content from custom.py

# Load the default screen
lv.scr_load(home_screen)

while SDL.check():
    time.sleep_ms(5)

