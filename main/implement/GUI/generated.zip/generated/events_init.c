/*
* Copyright 2023 NXP
* NXP Confidential and Proprietary. This software is owned or controlled by NXP and may only be used strictly in
* accordance with the applicable license terms. By expressly accepting such terms or by downloading, installing,
* activating and/or otherwise using the software, you are agreeing that you have read, and that you agree to
* comply with and are bound by, such license terms.  If you do not agree to be bound by the applicable license
* terms, then you may not retain, install, activate or otherwise use the software.
*/

#include "events_init.h"
#include <stdio.h>
#include "lvgl.h"


static void home_screen_information_btn_event_handler (lv_event_t *e)
{
	lv_event_code_t code = lv_event_get_code(e);

	switch (code) {
	case LV_EVENT_CLICKED:
	{
		//Write the load screen code.
	    lv_obj_t * act_scr = lv_scr_act();
	    lv_disp_t * d = lv_obj_get_disp(act_scr);
	    if (d->prev_scr == NULL && (d->scr_to_load == NULL || d->scr_to_load == act_scr)) {
	        if (guider_ui.information_screen_del == true) {
	          setup_scr_information_screen(&guider_ui);
	        }
	        lv_scr_load_anim(guider_ui.information_screen, LV_SCR_LOAD_ANIM_OVER_TOP, 200, 200, true);
	        guider_ui.information_screen_del = true;
	    }
		break;
	}
	default:
		break;
	}
}
static void home_screen_display_btn_event_handler (lv_event_t *e)
{
	lv_event_code_t code = lv_event_get_code(e);

	switch (code) {
	case LV_EVENT_CLICKED:
	{
		//Write the load screen code.
	    lv_obj_t * act_scr = lv_scr_act();
	    lv_disp_t * d = lv_obj_get_disp(act_scr);
	    if (d->prev_scr == NULL && (d->scr_to_load == NULL || d->scr_to_load == act_scr)) {
	        if (guider_ui.instant_picture_del == true) {
	          setup_scr_instant_picture(&guider_ui);
	        }
	        lv_scr_load_anim(guider_ui.instant_picture, LV_SCR_LOAD_ANIM_NONE, 200, 200, true);
	        guider_ui.instant_picture_del = true;
	    }
		break;
	}
	default:
		break;
	}
}
void events_init_home_screen(lv_ui *ui)
{
	lv_obj_add_event_cb(ui->home_screen_information_btn, home_screen_information_btn_event_handler, LV_EVENT_ALL, NULL);
	lv_obj_add_event_cb(ui->home_screen_display_btn, home_screen_display_btn_event_handler, LV_EVENT_ALL, NULL);
}
static void information_screen_event_handler (lv_event_t *e)
{
	lv_event_code_t code = lv_event_get_code(e);

	switch (code) {
	case LV_EVENT_CLICKED:
	{
		//Write the load screen code.
	    lv_obj_t * act_scr = lv_scr_act();
	    lv_disp_t * d = lv_obj_get_disp(act_scr);
	    if (d->prev_scr == NULL && (d->scr_to_load == NULL || d->scr_to_load == act_scr)) {
	        if (guider_ui.home_screen_del == true) {
	          setup_scr_home_screen(&guider_ui);
	        }
	        lv_scr_load_anim(guider_ui.home_screen, LV_SCR_LOAD_ANIM_NONE, 200, 200, true);
	        guider_ui.home_screen_del = true;
	    }
		break;
	}
	default:
		break;
	}
}
static void information_screen_BACK_btn1_event_handler (lv_event_t *e)
{
	lv_event_code_t code = lv_event_get_code(e);

	switch (code) {
	case LV_EVENT_CLICKED:
	{
		//Write the load screen code.
	    lv_obj_t * act_scr = lv_scr_act();
	    lv_disp_t * d = lv_obj_get_disp(act_scr);
	    if (d->prev_scr == NULL && (d->scr_to_load == NULL || d->scr_to_load == act_scr)) {
	        if (guider_ui.home_screen_del == true) {
	          setup_scr_home_screen(&guider_ui);
	        }
	        lv_scr_load_anim(guider_ui.home_screen, LV_SCR_LOAD_ANIM_NONE, 200, 200, true);
	        guider_ui.home_screen_del = true;
	    }
		break;
	}
	default:
		break;
	}
}
static void information_screen_abousus_btn_event_handler (lv_event_t *e)
{
	lv_event_code_t code = lv_event_get_code(e);

	switch (code) {
	case LV_EVENT_CLICKED:
	{
		//Write the load screen code.
	    lv_obj_t * act_scr = lv_scr_act();
	    lv_disp_t * d = lv_obj_get_disp(act_scr);
	    if (d->prev_scr == NULL && (d->scr_to_load == NULL || d->scr_to_load == act_scr)) {
	        if (guider_ui.introduction_page_del == true) {
	          setup_scr_introduction_page(&guider_ui);
	        }
	        lv_scr_load_anim(guider_ui.introduction_page, LV_SCR_LOAD_ANIM_NONE, 200, 200, true);
	        guider_ui.introduction_page_del = true;
	    }
		break;
	}
	default:
		break;
	}
}
static void information_screen_seemore_btn_event_handler (lv_event_t *e)
{
	lv_event_code_t code = lv_event_get_code(e);

	switch (code) {
	case LV_EVENT_CLICKED:
	{
		//Write the load screen code.
	    lv_obj_t * act_scr = lv_scr_act();
	    lv_disp_t * d = lv_obj_get_disp(act_scr);
	    if (d->prev_scr == NULL && (d->scr_to_load == NULL || d->scr_to_load == act_scr)) {
	        if (guider_ui.example_page1_del == true) {
	          setup_scr_example_page1(&guider_ui);
	        }
	        lv_scr_load_anim(guider_ui.example_page1, LV_SCR_LOAD_ANIM_NONE, 200, 200, true);
	        guider_ui.example_page1_del = true;
	    }
		break;
	}
	default:
		break;
	}
}
void events_init_information_screen(lv_ui *ui)
{
	lv_obj_add_event_cb(ui->information_screen, information_screen_event_handler, LV_EVENT_ALL, NULL);
	lv_obj_add_event_cb(ui->information_screen_BACK_btn1, information_screen_BACK_btn1_event_handler, LV_EVENT_ALL, NULL);
	lv_obj_add_event_cb(ui->information_screen_abousus_btn, information_screen_abousus_btn_event_handler, LV_EVENT_ALL, NULL);
	lv_obj_add_event_cb(ui->information_screen_seemore_btn, information_screen_seemore_btn_event_handler, LV_EVENT_ALL, NULL);
}
static void instant_picture_BACK_btn2_event_handler (lv_event_t *e)
{
	lv_event_code_t code = lv_event_get_code(e);

	switch (code) {
	case LV_EVENT_CLICKED:
	{
		//Write the load screen code.
	    lv_obj_t * act_scr = lv_scr_act();
	    lv_disp_t * d = lv_obj_get_disp(act_scr);
	    if (d->prev_scr == NULL && (d->scr_to_load == NULL || d->scr_to_load == act_scr)) {
	        if (guider_ui.home_screen_del == true) {
	          setup_scr_home_screen(&guider_ui);
	        }
	        lv_scr_load_anim(guider_ui.home_screen, LV_SCR_LOAD_ANIM_NONE, 200, 200, true);
	        guider_ui.home_screen_del = true;
	    }
		break;
	}
	default:
		break;
	}
}
void events_init_instant_picture(lv_ui *ui)
{
	lv_obj_add_event_cb(ui->instant_picture_BACK_btn2, instant_picture_BACK_btn2_event_handler, LV_EVENT_ALL, NULL);
}
static void example_page1_BACK_btn3_event_handler (lv_event_t *e)
{
	lv_event_code_t code = lv_event_get_code(e);

	switch (code) {
	case LV_EVENT_CLICKED:
	{
		//Write the load screen code.
	    lv_obj_t * act_scr = lv_scr_act();
	    lv_disp_t * d = lv_obj_get_disp(act_scr);
	    if (d->prev_scr == NULL && (d->scr_to_load == NULL || d->scr_to_load == act_scr)) {
	        if (guider_ui.information_screen_del == true) {
	          setup_scr_information_screen(&guider_ui);
	        }
	        lv_scr_load_anim(guider_ui.information_screen, LV_SCR_LOAD_ANIM_NONE, 200, 200, true);
	        guider_ui.information_screen_del = true;
	    }
		break;
	}
	default:
		break;
	}
}
static void example_page1_MORE_btn_event_handler (lv_event_t *e)
{
	lv_event_code_t code = lv_event_get_code(e);

	switch (code) {
	case LV_EVENT_CLICKED:
	{
		//Write the load screen code.
	    lv_obj_t * act_scr = lv_scr_act();
	    lv_disp_t * d = lv_obj_get_disp(act_scr);
	    if (d->prev_scr == NULL && (d->scr_to_load == NULL || d->scr_to_load == act_scr)) {
	        if (guider_ui.example_page2_del == true) {
	          setup_scr_example_page2(&guider_ui);
	        }
	        lv_scr_load_anim(guider_ui.example_page2, LV_SCR_LOAD_ANIM_NONE, 200, 200, true);
	        guider_ui.example_page2_del = true;
	    }
		break;
	}
	default:
		break;
	}
}
void events_init_example_page1(lv_ui *ui)
{
	lv_obj_add_event_cb(ui->example_page1_BACK_btn3, example_page1_BACK_btn3_event_handler, LV_EVENT_ALL, NULL);
	lv_obj_add_event_cb(ui->example_page1_MORE_btn, example_page1_MORE_btn_event_handler, LV_EVENT_ALL, NULL);
}
static void example_page2_BACK_btn4_event_handler (lv_event_t *e)
{
	lv_event_code_t code = lv_event_get_code(e);

	switch (code) {
	case LV_EVENT_CLICKED:
	{
		//Write the load screen code.
	    lv_obj_t * act_scr = lv_scr_act();
	    lv_disp_t * d = lv_obj_get_disp(act_scr);
	    if (d->prev_scr == NULL && (d->scr_to_load == NULL || d->scr_to_load == act_scr)) {
	        if (guider_ui.example_page1_del == true) {
	          setup_scr_example_page1(&guider_ui);
	        }
	        lv_scr_load_anim(guider_ui.example_page1, LV_SCR_LOAD_ANIM_NONE, 200, 200, true);
	        guider_ui.example_page1_del = true;
	    }
		break;
	}
	default:
		break;
	}
}
void events_init_example_page2(lv_ui *ui)
{
	lv_obj_add_event_cb(ui->example_page2_BACK_btn4, example_page2_BACK_btn4_event_handler, LV_EVENT_ALL, NULL);
}
static void introduction_page_BACK_btn5_event_handler (lv_event_t *e)
{
	lv_event_code_t code = lv_event_get_code(e);

	switch (code) {
	case LV_EVENT_CLICKED:
	{
		//Write the load screen code.
	    lv_obj_t * act_scr = lv_scr_act();
	    lv_disp_t * d = lv_obj_get_disp(act_scr);
	    if (d->prev_scr == NULL && (d->scr_to_load == NULL || d->scr_to_load == act_scr)) {
	        if (guider_ui.information_screen_del == true) {
	          setup_scr_information_screen(&guider_ui);
	        }
	        lv_scr_load_anim(guider_ui.information_screen, LV_SCR_LOAD_ANIM_NONE, 200, 200, true);
	        guider_ui.information_screen_del = true;
	    }
		break;
	}
	default:
		break;
	}
}
void events_init_introduction_page(lv_ui *ui)
{
	lv_obj_add_event_cb(ui->introduction_page_BACK_btn5, introduction_page_BACK_btn5_event_handler, LV_EVENT_ALL, NULL);
}

void events_init(lv_ui *ui)
{

}
