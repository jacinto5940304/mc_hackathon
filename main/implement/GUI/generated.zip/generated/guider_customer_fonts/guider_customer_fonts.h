// SPDX-License-Identifier: MIT
// Copyright 2020-2023 NXP
#ifndef GUIDER_CUSTOMER_FONTS_H
#define GUIDER_CUSTOMER_FONTS_H
#ifdef __cplusplus
extern "C" {
#endif

#include "lv_font.h"

#ifdef __cplusplus
}
#endif
#endif