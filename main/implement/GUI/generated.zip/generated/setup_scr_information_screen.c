/*
* Copyright 2023 NXP
* NXP Confidential and Proprietary. This software is owned or controlled by NXP and may only be used strictly in
* accordance with the applicable license terms. By expressly accepting such terms or by downloading, installing,
* activating and/or otherwise using the software, you are agreeing that you have read, and that you agree to
* comply with and are bound by, such license terms.  If you do not agree to be bound by the applicable license
* terms, then you may not retain, install, activate or otherwise use the software.
*/

#include "lvgl.h"
#include <stdio.h>
#include "gui_guider.h"
#include "events_init.h"
#include "widgets_init.h"
#include "custom.h"


void setup_scr_information_screen(lv_ui *ui)
{
	//Write codes information_screen
	ui->information_screen = lv_obj_create(NULL);
	lv_obj_set_size(ui->information_screen, 480, 272);
	lv_obj_set_scrollbar_mode(ui->information_screen, LV_SCROLLBAR_MODE_OFF);

	//Write style for information_screen, Part: LV_PART_MAIN, State: LV_STATE_DEFAULT.
	lv_obj_set_style_bg_opa(ui->information_screen, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_img_src(ui->information_screen, &_background_480x272, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_img_opa(ui->information_screen, 255, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_img_recolor(ui->information_screen, lv_color_hex(0x9893A7), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_img_recolor_opa(ui->information_screen, 142, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write codes information_screen_BACK_btn1
	ui->information_screen_BACK_btn1 = lv_btn_create(ui->information_screen);
	ui->information_screen_BACK_btn1_label = lv_label_create(ui->information_screen_BACK_btn1);
	lv_label_set_text(ui->information_screen_BACK_btn1_label, "BACK");
	lv_label_set_long_mode(ui->information_screen_BACK_btn1_label, LV_LABEL_LONG_WRAP);
	lv_obj_align(ui->information_screen_BACK_btn1_label, LV_ALIGN_CENTER, 0, 0);
	lv_obj_set_style_pad_all(ui->information_screen_BACK_btn1, 0, LV_STATE_DEFAULT);
	lv_obj_set_pos(ui->information_screen_BACK_btn1, 70, 173);
	lv_obj_set_size(ui->information_screen_BACK_btn1, 60, 100);
	lv_obj_set_scrollbar_mode(ui->information_screen_BACK_btn1, LV_SCROLLBAR_MODE_OFF);

	//Write style for information_screen_BACK_btn1, Part: LV_PART_MAIN, State: LV_STATE_DEFAULT.
	lv_obj_set_style_bg_opa(ui->information_screen_BACK_btn1, 195, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_color(ui->information_screen_BACK_btn1, lv_color_hex(0x9893A7), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_border_width(ui->information_screen_BACK_btn1, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_radius(ui->information_screen_BACK_btn1, 5, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_shadow_width(ui->information_screen_BACK_btn1, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_color(ui->information_screen_BACK_btn1, lv_color_hex(0xffffff), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_font(ui->information_screen_BACK_btn1, &lv_font_montserratMedium_16, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_align(ui->information_screen_BACK_btn1, LV_TEXT_ALIGN_CENTER, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write codes information_screen_abousus_btn
	ui->information_screen_abousus_btn = lv_btn_create(ui->information_screen);
	ui->information_screen_abousus_btn_label = lv_label_create(ui->information_screen_abousus_btn);
	lv_label_set_text(ui->information_screen_abousus_btn_label, "about \nus");
	lv_label_set_long_mode(ui->information_screen_abousus_btn_label, LV_LABEL_LONG_WRAP);
	lv_obj_align(ui->information_screen_abousus_btn_label, LV_ALIGN_CENTER, 0, 0);
	lv_obj_set_style_pad_all(ui->information_screen_abousus_btn, 0, LV_STATE_DEFAULT);
	lv_obj_set_pos(ui->information_screen_abousus_btn, 210, 133);
	lv_obj_set_size(ui->information_screen_abousus_btn, 60, 140);
	lv_obj_set_scrollbar_mode(ui->information_screen_abousus_btn, LV_SCROLLBAR_MODE_OFF);

	//Write style for information_screen_abousus_btn, Part: LV_PART_MAIN, State: LV_STATE_DEFAULT.
	lv_obj_set_style_bg_opa(ui->information_screen_abousus_btn, 216, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_color(ui->information_screen_abousus_btn, lv_color_hex(0x9893A7), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_border_width(ui->information_screen_abousus_btn, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_radius(ui->information_screen_abousus_btn, 5, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_shadow_width(ui->information_screen_abousus_btn, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_color(ui->information_screen_abousus_btn, lv_color_hex(0xffffff), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_font(ui->information_screen_abousus_btn, &lv_font_montserratMedium_16, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_align(ui->information_screen_abousus_btn, LV_TEXT_ALIGN_CENTER, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write codes information_screen_seemore_btn
	ui->information_screen_seemore_btn = lv_btn_create(ui->information_screen);
	ui->information_screen_seemore_btn_label = lv_label_create(ui->information_screen_seemore_btn);
	lv_label_set_text(ui->information_screen_seemore_btn_label, "see\nmore\n\n");
	lv_label_set_long_mode(ui->information_screen_seemore_btn_label, LV_LABEL_LONG_WRAP);
	lv_obj_align(ui->information_screen_seemore_btn_label, LV_ALIGN_CENTER, 0, 0);
	lv_obj_set_style_pad_all(ui->information_screen_seemore_btn, 0, LV_STATE_DEFAULT);
	lv_obj_set_pos(ui->information_screen_seemore_btn, 350, 93);
	lv_obj_set_size(ui->information_screen_seemore_btn, 60, 180);
	lv_obj_set_scrollbar_mode(ui->information_screen_seemore_btn, LV_SCROLLBAR_MODE_OFF);

	//Write style for information_screen_seemore_btn, Part: LV_PART_MAIN, State: LV_STATE_DEFAULT.
	lv_obj_set_style_bg_opa(ui->information_screen_seemore_btn, 216, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_color(ui->information_screen_seemore_btn, lv_color_hex(0x9893A7), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_border_width(ui->information_screen_seemore_btn, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_radius(ui->information_screen_seemore_btn, 5, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_shadow_width(ui->information_screen_seemore_btn, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_color(ui->information_screen_seemore_btn, lv_color_hex(0xffffff), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_font(ui->information_screen_seemore_btn, &lv_font_montserratMedium_16, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_align(ui->information_screen_seemore_btn, LV_TEXT_ALIGN_CENTER, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write codes information_screen_btn_5
	ui->information_screen_btn_5 = lv_btn_create(ui->information_screen);
	ui->information_screen_btn_5_label = lv_label_create(ui->information_screen_btn_5);
	lv_label_set_text(ui->information_screen_btn_5_label, "");
	lv_label_set_long_mode(ui->information_screen_btn_5_label, LV_LABEL_LONG_WRAP);
	lv_obj_align(ui->information_screen_btn_5_label, LV_ALIGN_CENTER, 0, 0);
	lv_obj_set_style_pad_all(ui->information_screen_btn_5, 0, LV_STATE_DEFAULT);
	lv_obj_set_pos(ui->information_screen_btn_5, 320, 1);
	lv_obj_set_size(ui->information_screen_btn_5, 35, 50);
	lv_obj_set_scrollbar_mode(ui->information_screen_btn_5, LV_SCROLLBAR_MODE_OFF);

	//Write style for information_screen_btn_5, Part: LV_PART_MAIN, State: LV_STATE_DEFAULT.
	lv_obj_set_style_bg_opa(ui->information_screen_btn_5, 255, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_color(ui->information_screen_btn_5, lv_color_hex(0xd4d2da), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_border_width(ui->information_screen_btn_5, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_radius(ui->information_screen_btn_5, 5, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_shadow_width(ui->information_screen_btn_5, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_color(ui->information_screen_btn_5, lv_color_hex(0xffffff), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_font(ui->information_screen_btn_5, &lv_font_montserratMedium_16, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_align(ui->information_screen_btn_5, LV_TEXT_ALIGN_CENTER, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write codes information_screen_btn_6
	ui->information_screen_btn_6 = lv_btn_create(ui->information_screen);
	ui->information_screen_btn_6_label = lv_label_create(ui->information_screen_btn_6);
	lv_label_set_text(ui->information_screen_btn_6_label, "");
	lv_label_set_long_mode(ui->information_screen_btn_6_label, LV_LABEL_LONG_WRAP);
	lv_obj_align(ui->information_screen_btn_6_label, LV_ALIGN_CENTER, 0, 0);
	lv_obj_set_style_pad_all(ui->information_screen_btn_6, 0, LV_STATE_DEFAULT);
	lv_obj_set_pos(ui->information_screen_btn_6, 177, 1);
	lv_obj_set_size(ui->information_screen_btn_6, 35, 70);
	lv_obj_set_scrollbar_mode(ui->information_screen_btn_6, LV_SCROLLBAR_MODE_OFF);

	//Write style for information_screen_btn_6, Part: LV_PART_MAIN, State: LV_STATE_DEFAULT.
	lv_obj_set_style_bg_opa(ui->information_screen_btn_6, 255, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_color(ui->information_screen_btn_6, lv_color_hex(0xd4d2da), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_border_width(ui->information_screen_btn_6, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_radius(ui->information_screen_btn_6, 5, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_shadow_width(ui->information_screen_btn_6, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_color(ui->information_screen_btn_6, lv_color_hex(0xffffff), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_font(ui->information_screen_btn_6, &lv_font_montserratMedium_16, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_align(ui->information_screen_btn_6, LV_TEXT_ALIGN_CENTER, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write codes information_screen_btn_7
	ui->information_screen_btn_7 = lv_btn_create(ui->information_screen);
	ui->information_screen_btn_7_label = lv_label_create(ui->information_screen_btn_7);
	lv_label_set_text(ui->information_screen_btn_7_label, "");
	lv_label_set_long_mode(ui->information_screen_btn_7_label, LV_LABEL_LONG_WRAP);
	lv_obj_align(ui->information_screen_btn_7_label, LV_ALIGN_CENTER, 0, 0);
	lv_obj_set_style_pad_all(ui->information_screen_btn_7, 0, LV_STATE_DEFAULT);
	lv_obj_set_pos(ui->information_screen_btn_7, 31, 1);
	lv_obj_set_size(ui->information_screen_btn_7, 35, 90);
	lv_obj_set_scrollbar_mode(ui->information_screen_btn_7, LV_SCROLLBAR_MODE_OFF);

	//Write style for information_screen_btn_7, Part: LV_PART_MAIN, State: LV_STATE_DEFAULT.
	lv_obj_set_style_bg_opa(ui->information_screen_btn_7, 255, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_color(ui->information_screen_btn_7, lv_color_hex(0xd4d2da), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_border_width(ui->information_screen_btn_7, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_radius(ui->information_screen_btn_7, 5, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_shadow_width(ui->information_screen_btn_7, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_color(ui->information_screen_btn_7, lv_color_hex(0xffffff), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_font(ui->information_screen_btn_7, &lv_font_montserratMedium_16, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_align(ui->information_screen_btn_7, LV_TEXT_ALIGN_CENTER, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Update current screen layout.
	lv_obj_update_layout(ui->information_screen);

	
	//Init events for screen.
	events_init_information_screen(ui);
}
