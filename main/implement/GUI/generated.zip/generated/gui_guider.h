/*
* Copyright 2023 NXP
* NXP Confidential and Proprietary. This software is owned or controlled by NXP and may only be used strictly in
* accordance with the applicable license terms. By expressly accepting such terms or by downloading, installing,
* activating and/or otherwise using the software, you are agreeing that you have read, and that you agree to
* comply with and are bound by, such license terms.  If you do not agree to be bound by the applicable license
* terms, then you may not retain, install, activate or otherwise use the software.
*/

#ifndef GUI_GUIDER_H
#define GUI_GUIDER_H
#ifdef __cplusplus
extern "C" {
#endif

#include "lvgl.h"

typedef struct
{
  
	lv_obj_t *home_screen;
	bool home_screen_del;
	lv_obj_t *home_screen_information_btn;
	lv_obj_t *home_screen_information_btn_label;
	lv_obj_t *home_screen_display_btn;
	lv_obj_t *home_screen_display_btn_label;
	lv_obj_t *home_screen_information_label;
	lv_obj_t *home_screen_display_label;
	lv_obj_t *information_screen;
	bool information_screen_del;
	lv_obj_t *information_screen_BACK_btn1;
	lv_obj_t *information_screen_BACK_btn1_label;
	lv_obj_t *information_screen_abousus_btn;
	lv_obj_t *information_screen_abousus_btn_label;
	lv_obj_t *information_screen_seemore_btn;
	lv_obj_t *information_screen_seemore_btn_label;
	lv_obj_t *information_screen_btn_5;
	lv_obj_t *information_screen_btn_5_label;
	lv_obj_t *information_screen_btn_6;
	lv_obj_t *information_screen_btn_6_label;
	lv_obj_t *information_screen_btn_7;
	lv_obj_t *information_screen_btn_7_label;
	lv_obj_t *instant_picture;
	bool instant_picture_del;
	lv_obj_t *instant_picture_img_1;
	lv_obj_t *instant_picture_BACK_btn2;
	lv_obj_t *instant_picture_BACK_btn2_label;
	lv_obj_t *instant_picture_img_2;
	lv_obj_t *example_page1;
	bool example_page1_del;
	lv_obj_t *example_page1_BACK_btn3;
	lv_obj_t *example_page1_BACK_btn3_label;
	lv_obj_t *example_page1_MORE_btn;
	lv_obj_t *example_page1_MORE_btn_label;
	lv_obj_t *example_page2;
	bool example_page2_del;
	lv_obj_t *example_page2_BACK_btn4;
	lv_obj_t *example_page2_BACK_btn4_label;
	lv_obj_t *introduction_page;
	bool introduction_page_del;
	lv_obj_t *introduction_page_BACK_btn5;
	lv_obj_t *introduction_page_BACK_btn5_label;
	lv_obj_t *introduction_page_qrcode_1;
	lv_obj_t *introduction_page_label_1;
}lv_ui;

void ui_init_style(lv_style_t * style);
void init_scr_del_flag(lv_ui *ui);
void setup_ui(lv_ui *ui);
extern lv_ui guider_ui;

void setup_scr_home_screen(lv_ui *ui);
void setup_scr_information_screen(lv_ui *ui);
void setup_scr_instant_picture(lv_ui *ui);
void setup_scr_example_page1(lv_ui *ui);
void setup_scr_example_page2(lv_ui *ui);
void setup_scr_introduction_page(lv_ui *ui);

LV_IMG_DECLARE(_background_480x272);

LV_IMG_DECLARE(_setting1_104x91);

LV_IMG_DECLARE(_ant_button_215x115);

LV_IMG_DECLARE(_background_480x272);

LV_IMG_DECLARE(_background_480x272);
LV_IMG_DECLARE(_Direction_alpha_645x322);
LV_IMG_DECLARE(_arrow_alpha_45x105);

LV_IMG_DECLARE(_example_page1_480x272);

LV_IMG_DECLARE(_example_page2_480x272);

LV_IMG_DECLARE(_background_480x272);

LV_FONT_DECLARE(lv_font_montserratMedium_16)
LV_FONT_DECLARE(lv_font_montserratMedium_12)


#ifdef __cplusplus
}
#endif
#endif
