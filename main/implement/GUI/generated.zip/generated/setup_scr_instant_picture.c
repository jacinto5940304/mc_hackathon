/*
* Copyright 2023 NXP
* NXP Confidential and Proprietary. This software is owned or controlled by NXP and may only be used strictly in
* accordance with the applicable license terms. By expressly accepting such terms or by downloading, installing,
* activating and/or otherwise using the software, you are agreeing that you have read, and that you agree to
* comply with and are bound by, such license terms.  If you do not agree to be bound by the applicable license
* terms, then you may not retain, install, activate or otherwise use the software.
*/

#include "lvgl.h"
#include <stdio.h>
#include "gui_guider.h"
#include "events_init.h"
#include "widgets_init.h"
#include "custom.h"


void setup_scr_instant_picture(lv_ui *ui)
{
	//Write codes instant_picture
	ui->instant_picture = lv_obj_create(NULL);
	lv_obj_set_size(ui->instant_picture, 480, 272);
	lv_obj_set_scrollbar_mode(ui->instant_picture, LV_SCROLLBAR_MODE_OFF);

	//Write style for instant_picture, Part: LV_PART_MAIN, State: LV_STATE_DEFAULT.
	lv_obj_set_style_bg_opa(ui->instant_picture, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_img_src(ui->instant_picture, &_background_480x272, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_img_opa(ui->instant_picture, 255, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_img_recolor(ui->instant_picture, lv_color_hex(0x67ff00), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_img_recolor_opa(ui->instant_picture, 34, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write codes instant_picture_img_1
	ui->instant_picture_img_1 = lv_img_create(ui->instant_picture);
	lv_obj_add_flag(ui->instant_picture_img_1, LV_OBJ_FLAG_CLICKABLE);
	lv_img_set_src(ui->instant_picture_img_1, &_Direction_alpha_645x322);
	lv_img_set_pivot(ui->instant_picture_img_1, 310,156);
	lv_img_set_angle(ui->instant_picture_img_1, 0);
	lv_obj_set_pos(ui->instant_picture_img_1, -69, -25);
	lv_obj_set_size(ui->instant_picture_img_1, 645, 322);
	lv_obj_set_scrollbar_mode(ui->instant_picture_img_1, LV_SCROLLBAR_MODE_OFF);

	//Write style for instant_picture_img_1, Part: LV_PART_MAIN, State: LV_STATE_DEFAULT.
	lv_obj_set_style_img_opa(ui->instant_picture_img_1, 255, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write codes instant_picture_BACK_btn2
	ui->instant_picture_BACK_btn2 = lv_btn_create(ui->instant_picture);
	ui->instant_picture_BACK_btn2_label = lv_label_create(ui->instant_picture_BACK_btn2);
	lv_label_set_text(ui->instant_picture_BACK_btn2_label, "BACK");
	lv_label_set_long_mode(ui->instant_picture_BACK_btn2_label, LV_LABEL_LONG_WRAP);
	lv_obj_align(ui->instant_picture_BACK_btn2_label, LV_ALIGN_CENTER, 0, 0);
	lv_obj_set_style_pad_all(ui->instant_picture_BACK_btn2, 0, LV_STATE_DEFAULT);
	lv_obj_set_pos(ui->instant_picture_BACK_btn2, 0, 17);
	lv_obj_set_size(ui->instant_picture_BACK_btn2, 118, 35);
	lv_obj_set_scrollbar_mode(ui->instant_picture_BACK_btn2, LV_SCROLLBAR_MODE_OFF);
	//Update pos for widget instant_picture_BACK_btn2
	lv_obj_update_layout(ui->instant_picture_BACK_btn2);
	//Write animation: instant_picture_BACK_btn2 move in x direction
	lv_anim_t instant_picture_BACK_btn2_x;
	lv_anim_init(&instant_picture_BACK_btn2_x);
	lv_anim_set_var(&instant_picture_BACK_btn2_x, ui->instant_picture_BACK_btn2);
	lv_anim_set_time(&instant_picture_BACK_btn2_x, 1000);
	lv_anim_set_exec_cb(&instant_picture_BACK_btn2_x, (lv_anim_exec_xcb_t)lv_obj_set_x);
	lv_anim_set_values(&instant_picture_BACK_btn2_x, lv_obj_get_x(ui->instant_picture_BACK_btn2), 0);
	lv_anim_set_path_cb(&instant_picture_BACK_btn2_x, lv_anim_path_linear);
	lv_anim_start(&instant_picture_BACK_btn2_x);
	//Write animation: instant_picture_BACK_btn2 move in y direction
	lv_anim_t instant_picture_BACK_btn2_y;
	lv_anim_init(&instant_picture_BACK_btn2_y);
	lv_anim_set_var(&instant_picture_BACK_btn2_y, ui->instant_picture_BACK_btn2);
	lv_anim_set_time(&instant_picture_BACK_btn2_y, 1000);
	lv_anim_set_exec_cb(&instant_picture_BACK_btn2_y, (lv_anim_exec_xcb_t)lv_obj_set_y);
	lv_anim_set_values(&instant_picture_BACK_btn2_y, lv_obj_get_y(ui->instant_picture_BACK_btn2), 0);
	lv_anim_set_path_cb(&instant_picture_BACK_btn2_y, lv_anim_path_linear);
	lv_anim_start(&instant_picture_BACK_btn2_y);

	//Write style for instant_picture_BACK_btn2, Part: LV_PART_MAIN, State: LV_STATE_DEFAULT.
	lv_obj_set_style_bg_opa(ui->instant_picture_BACK_btn2, 195, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_color(ui->instant_picture_BACK_btn2, lv_color_hex(0x9893A7), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_border_width(ui->instant_picture_BACK_btn2, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_radius(ui->instant_picture_BACK_btn2, 5, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_shadow_width(ui->instant_picture_BACK_btn2, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_color(ui->instant_picture_BACK_btn2, lv_color_hex(0xffffff), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_font(ui->instant_picture_BACK_btn2, &lv_font_montserratMedium_16, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_align(ui->instant_picture_BACK_btn2, LV_TEXT_ALIGN_CENTER, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Update current screen layout.
	lv_obj_update_layout(ui->instant_picture);

	
	//Init events for screen.
	events_init_instant_picture(ui);
}
